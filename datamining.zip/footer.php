
	<div class="container2" style="border:1px solid #d2d2d7; background-color:#d2d2d7;">
		<center><h3><b>Copyright © <?php echo date('Y') ?>. | Hj.Mbok Sri Kota Palu</b></h3></center>
	</div>