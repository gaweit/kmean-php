<?php
	session_destroy();
	echo "<META HTTP-EQUIV='Refresh' Content='0; URL=?module=index.php'>";
?>