
<div class="span12" >
          <div class="widget widget-nopad">
            <div class="widget-header"> <i class="icon-home"></i>
              <h3> Selamat datang, <b><u><?php echo"$_SESSION[nmadmin]"; ?></u></b></h3>
            </div>
            <!-- /widget-header -->
            <div class="widget-content">
              <div class="widget big-stats-container">
                <div class="widget-content">
				<img src="images/baneri.png" width="100%"><br><hr>
                 <span>
                   Data Mining adalah rangkaian kegiatan untuk menemukan pola yang menarik dari data dalam jumlah besar, kemudia data – data tersebut dapat disimpan dalam database, data warehouse atau penyimpanan informasi (Prilianti, 2014).
                 </span> 
                 <hr>
                 <span>
                   Clustering merupakan suatu metode untuk melakukan pengelompokkan berdasarkan kesamaan atau kemiripan parameter pada data. Clustering berbeda dari klasifikasi dimana pada clustering tidak ada variabel target untuk pengelompokkan.
                 </span>
                  </div>
                </div>
                <!-- /widget-content --> 
                
              </div>
            </div>
          </div>
          <!-- /widget -->
          
          <!-- /widget -->
          <!-- /widget --> 
        </div>
        